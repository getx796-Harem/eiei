import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, 
  Settings, 
  Ticket as TicketIcon, 
  MessageSquare, 
  Server, 
  User, 
  LogOut,
  Send,
  Plus,
  Loader2,
  ShieldCheck,
  Users,
  CheckCircle,
  XCircle,
  Clock,
  UserPlus,
  Search,
  Hash,
  Palette,
  Music,
  Play,
  Pause,
  Volume2,
  VolumeX,
  SkipForward,
  Radio,
  Mic,
  MicOff,
  Phone,
  PhoneOff,
  RotateCcw
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import ReactPlayerImport from 'react-player';
const ReactPlayer = ReactPlayerImport as any;
import { db } from './lib/firebase';
import { 
  collection, 
  query, 
  where, 
  onSnapshot, 
  addDoc, 
  serverTimestamp, 
  orderBy,
  limit,
  doc,
  setDoc,
  getDoc,
  updateDoc,
  getDocs,
  deleteDoc
} from 'firebase/firestore';

// --- Error Handling ---

enum OperationType {
  CREATE = 'create',
  UPDATE = 'update',
  DELETE = 'delete',
  LIST = 'list',
  GET = 'get',
  WRITE = 'write',
}

interface FirestoreErrorInfo {
  error: string;
  operationType: OperationType;
  path: string | null;
  authInfo: any;
}

function handleFirestoreError(error: unknown, operationType: OperationType, path: string | null) {
  const errInfo: FirestoreErrorInfo = {
    error: error instanceof Error ? error.message : String(error),
    authInfo: localStorage.getItem('ticket_user'),
    operationType,
    path
  }
  console.error('Firestore Error: ', JSON.stringify(errInfo));
  throw new Error(JSON.stringify(errInfo));
}

// --- Types ---

interface AppUser {
  id: string;
  username: string;
  password?: string;
  role: 'admin' | 'user';
  status: 'pending' | 'approved' | 'rejected';
  createdAt: any;
}

interface AppearanceSettings {
  primaryColor: string;
  bgGradient: string;
  accentColor: string;
}

interface MusicSettings {
  url: string;
  playing: boolean;
  volume: number;
  lastUpdated: any;
}

// --- Types ---

interface Guild {
  id: string;
  name: string;
  icon: string | null;
}

interface Ticket {
  id: string;
  guildId: string;
  userId: string;
  userName: string;
  status: 'open' | 'closed';
  createdAt: any;
}

interface Message {
  id: string;
  ticketId: string;
  authorId: string;
  authorName: string;
  content: string;
  source: 'discord' | 'web';
  createdAt: any;
}

// --- Components ---

export default function App() {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);
  const [hasInteracted, setHasInteracted] = useState(false);
  const [playerReady, setPlayerReady] = useState(false);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'tickets' | 'guilds' | 'users' | 'settings' | 'ticket-config' | 'voice'>('dashboard');
  const [activeBots, setActiveBots] = useState<any[]>([]);
  
  useEffect(() => {
    if (user) {
      fetch('/api/bot/config')
        .then(res => res.json())
        .then(data => setActiveBots(Array.isArray(data) ? data : []))
        .catch(() => {});
    }
  }, [user]);
  
  const [appearance, setAppearance] = useState<AppearanceSettings>({
    primaryColor: '#6366f1',
    accentColor: '#4f46e5',
    bgGradient: 'from-[#0F172A] to-[#020617]'
  });
  
  const [music, setMusic] = useState<MusicSettings>({
    url: '',
    playing: false,
    volume: 0.5,
    lastUpdated: null
  });

  useEffect(() => {
    setPlayerReady(false);
  }, [music.url]);

  useEffect(() => {
    const initSettings = async () => {
      const appRef = doc(db, 'settings', 'appearance');
      const appSnap = await getDoc(appRef);
      if (!appSnap.exists()) {
        await setDoc(appRef, {
          primaryColor: '#6366f1',
          accentColor: '#4f46e5',
          bgGradient: 'from-[#0F172A] to-[#020617]'
        });
      }

      const musRef = doc(db, 'settings', 'music');
      const musSnap = await getDoc(musRef);
      if (!musSnap.exists()) {
        await setDoc(musRef, {
          url: '',
          playing: false,
          volume: 0.5,
          lastUpdated: serverTimestamp()
        });
      }
    };
    initSettings();
  }, []);

  useEffect(() => {
    return onSnapshot(doc(db, 'settings', 'appearance'), (snap) => {
      if (snap.exists()) {
        setAppearance(snap.data() as AppearanceSettings);
      }
    });
  }, []);

  useEffect(() => {
    return onSnapshot(doc(db, 'settings', 'music'), (snap) => {
      if (snap.exists()) {
        setMusic(snap.data() as MusicSettings);
      }
    });
  }, []);

  useEffect(() => {
    const savedUser = localStorage.getItem('ticket_user');
    if (savedUser) {
      try {
        const parsed = JSON.parse(savedUser);
        getDoc(doc(db, 'app_users', parsed.id))
          .then(snap => {
            if (snap.exists() && snap.data().status === 'approved') {
              setUser({ id: snap.id, ...snap.data() } as AppUser);
            } else {
              localStorage.removeItem('ticket_user');
            }
            setLoading(false);
          })
          .catch((error) => {
            console.error('Initial user fetch error:', error);
            localStorage.removeItem('ticket_user');
            setLoading(false);
          });
      } catch {
        setLoading(false);
      }
    } else {
      setLoading(false);
    }
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('ticket_user');
    setUser(null);
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-[#020617] text-white font-sans">
        <Loader2 className="w-8 h-8 animate-spin text-indigo-500" />
      </div>
    );
  }

  if (!user) {
    return <LoginView onLogin={setUser} />;
  }

  return (
    <div 
      onClick={() => !hasInteracted && setHasInteracted(true)}
      className={`flex h-screen bg-[#0F172A] text-slate-200 overflow-hidden font-sans`}
    >
      <style>{`
        :root {
          --primary-color: ${appearance.primaryColor};
          --accent-color: ${appearance.accentColor};
        }
        .bg-custom-primary { background-color: var(--primary-color); }
        .text-custom-primary { color: var(--primary-color); }
        .border-custom-primary { border-color: var(--primary-color); }
        .shadow-custom-primary { --tw-shadow-color: var(--primary-color); }
      `}</style>
      
      {/* Global Music Player (Hidden/Minimal) */}
      <div className="hidden">
        <ReactPlayer 
          url={music.url || ''} 
          playing={Boolean(music.url && music.playing && hasInteracted && playerReady)} 
          volume={music.volume}
          loop={true}
          onReady={() => setPlayerReady(true)}
          onError={(e: any) => {
            console.error('Audio Sync Error:', e);
            setPlayerReady(false);
          }}
        />
      </div>

      {/* Autoplay Sync Overlay */}
      <AnimatePresence>
        {music.playing && !hasInteracted && (
          <motion.div 
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 50 }}
            className="fixed bottom-8 right-8 z-[100]"
          >
            <button 
              onClick={() => setHasInteracted(true)}
              className="group flex items-center gap-4 bg-indigo-600 hover:bg-indigo-500 text-white px-6 py-4 rounded-2xl shadow-2xl shadow-indigo-500/40 transition-all active:scale-95 border border-white/20"
            >
              <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center animate-pulse">
                <Radio className="w-5 h-5 text-white" />
              </div>
              <div className="text-left">
                <p className="text-[10px] font-black uppercase tracking-widest opacity-70">Stream Detected</p>
                <p className="text-sm font-bold">Join Broadcast Sync</p>
              </div>
            </button>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Sidebar */}
      <nav className="w-64 border-r border-[#1E293B] bg-[#020617]/80 backdrop-blur-xl flex flex-col p-4">
        <div className="flex items-center gap-3 px-2 mb-10 mt-2">
          <div className="w-10 h-10 bg-indigo-600 rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20">
            <TicketIcon className="w-6 h-6 text-white" />
          </div>
          <span className="font-bold text-xl tracking-tight text-white">TicketMaster</span>
        </div>

        <div className="flex-1 space-y-1.5">
          <NavItem 
            active={activeTab === 'dashboard'} 
            onClick={() => setActiveTab('dashboard')}
            icon={<LayoutDashboard className="w-5 h-5" />}
            label="Dashboard"
          />
          <NavItem 
            active={activeTab === 'tickets'} 
            onClick={() => setActiveTab('tickets')}
            icon={<MessageSquare className="w-5 h-5" />}
            label="Tickets"
          />
          <NavItem 
            active={activeTab === 'guilds'} 
            onClick={() => setActiveTab('guilds')}
            icon={<Server className="w-5 h-5" />}
            label="Servers"
          />
          {user.role === 'admin' && (
            <NavItem 
              active={activeTab === 'users'} 
              onClick={() => setActiveTab('users')}
              icon={<Users className="w-5 h-5" />}
              label="Staff Management"
            />
          )}
          {user.role === 'admin' && (
            <NavItem 
              active={activeTab === 'ticket-config'} 
              onClick={() => setActiveTab('ticket-config')}
              icon={<Plus className="w-5 h-5" />}
              label="PV Ticket"
            />
          )}
          {user.role === 'admin' && (
            <NavItem 
              active={activeTab === 'voice'} 
              onClick={() => setActiveTab('voice')}
              icon={<Mic className="w-5 h-5" />}
              label="Join Room"
            />
          )}
          {user.role === 'admin' && (
            <NavItem 
              active={activeTab === 'settings'} 
              onClick={() => setActiveTab('settings')}
              icon={<Settings className="w-5 h-5" />}
              label="Terminal Config"
            />
          )}
        </div>

        {/* Music Widget */}
        <div className="mt-4 p-3 bg-[#0F172A]/50 rounded-2xl border border-[#1E293B] space-y-2">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <Music className="w-3.5 h-3.5 text-indigo-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500">Audio Sync</span>
            </div>
            {music.playing ? (
              <span className="flex h-1.5 w-1.5 rounded-full bg-emerald-500 animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.8)]" />
            ) : (
              <span className="h-1.5 w-1.5 rounded-full bg-rose-500" />
            )}
          </div>
          
          <div className="flex items-center gap-2">
            {user?.role === 'admin' ? (
              <button 
                onClick={() => {
                  const newPlaying = !music.playing;
                  updateDoc(doc(db, 'settings', 'music'), { playing: newPlaying });
                }}
                style={{ backgroundColor: 'var(--primary-color)' }}
                className="w-7 h-7 rounded-lg flex items-center justify-center text-white hover:opacity-90 transition-all active:scale-90"
              >
                {music.playing ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              </button>
            ) : (
              <button 
                onClick={() => {
                  // This is to trigger the browser audio interaction
                  const p = document.querySelector('video, audio') as HTMLMediaElement;
                  if (p) p.play().catch(() => {});
                }}
                className="w-7 h-7 bg-slate-800 rounded-lg flex items-center justify-center text-slate-400 hover:bg-slate-700 transition-all"
                title="Join Broadcast"
              >
                <Radio className="w-3.5 h-3.5 text-indigo-400" />
              </button>
            )}
            <div className="flex-1 min-w-0">
               <div className="text-[9px] font-bold text-slate-400 truncate tracking-tight">{music.url ? (music.playing ? 'Live Broadcast' : 'Stream Paused') : 'No Stream'}</div>
               <div className="flex items-center gap-1 group">
                 {music.volume > 0 ? <Volume2 className="w-2.5 h-2.5 text-slate-600" /> : <VolumeX className="w-2.5 h-2.5 text-rose-500" />}
                 <input 
                  type="range" 
                  min="0" 
                  max="1" 
                  step="0.01" 
                  value={music.volume}
                  onChange={(e) => updateDoc(doc(db, 'settings', 'music'), { volume: parseFloat(e.target.value) })}
                  className="w-full h-1 bg-slate-800 rounded-full appearance-none cursor-pointer accent-indigo-500" 
                 />
               </div>
            </div>
          </div>
          {!music.playing && music.url && user?.role !== 'admin' && (
            <div className="text-[8px] font-bold text-rose-500/50 uppercase tracking-widest text-center animate-pulse">Wait for admin to play</div>
          )}
        </div>

        <div className="mt-auto pt-4 border-t border-[#1E293B]">
          <div className="flex items-center gap-3 px-2 py-3 bg-[#0F172A]/50 rounded-2xl border border-[#1E293B]">
            <div className="w-9 h-9 rounded-full bg-indigo-500/10 flex items-center justify-center border border-indigo-500/30 text-indigo-400 font-bold uppercase">
              {user.username.charAt(0)}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-semibold truncate text-white">{user.username}</p>
              <p className="text-[10px] text-slate-400 truncate uppercase tracking-wider">{user.role}</p>
            </div>
            <button onClick={handleLogout} className="p-1.5 hover:bg-slate-800 rounded-lg text-slate-400 transition-colors">
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Main Content */}
      <main className="flex-1 flex flex-col overflow-hidden relative">
        <header className="h-16 border-b border-[#1E293B] flex items-center justify-between px-8 bg-[#0F172A]/40 backdrop-blur-md">
          <div className="flex items-center gap-3">
            <span className="w-1.5 h-1.5 rounded-full bg-indigo-500 shadow-[0_0_8px_rgba(99,102,241,0.6)]" />
            <h1 className="text-sm font-bold text-slate-300 uppercase tracking-[0.2em]">{activeTab}</h1>
          </div>
          <div className="flex gap-4">
             <div className={`flex items-center gap-2 px-3 py-1.5 rounded-lg text-[10px] font-bold uppercase tracking-wider ${activeBots.length > 0 ? 'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20' : 'bg-rose-500/10 text-rose-400 border border-rose-500/20'}`}>
                <div className={`w-1.5 h-1.5 rounded-full ${activeBots.length > 0 ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.6)]' : 'bg-rose-500'}`} />
                Bot {activeBots.length > 0 ? 'System Online' : 'System Offline'}
             </div>
          </div>
        </header>

        <div className="flex-1 overflow-auto bg-[#0F172A]">
          <AnimatePresence mode="wait">
        {activeTab === 'dashboard' && <DashboardView activeBots={activeBots} setActiveBots={setActiveBots} />}
            {activeTab === 'guilds' && <GuildsView key="guilds" />}
            {activeTab === 'tickets' && <TicketsView key="tickets" />}
            {activeTab === 'users' && <UsersManagementView key="users" />}
            {activeTab === 'settings' && <SystemSettingsView appearance={appearance} music={music} key="settings" />}
            {activeTab === 'ticket-config' && <TicketConfigView key="ticket-config" />}
            {activeTab === 'voice' && <VoiceConsoleView key="voice" />}
          </AnimatePresence>
        </div>
      </main>
    </div>
  );
}

function NavItem({ active, onClick, icon, label }: any) {
  return (
    <button
      onClick={onClick}
      className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all text-sm font-semibold tracking-wide ${
        active 
          ? 'bg-custom-primary text-white shadow-lg' 
          : 'text-slate-400 hover:text-white hover:bg-slate-800/40'
      }`}
      style={active ? { backgroundColor: 'var(--primary-color)' } : {}}
    >
      <div className={active ? 'text-white' : 'text-slate-500'}>{icon}</div>
      {label}
      {active && (
        <motion.div 
          layoutId="nav-pill"
          className="ml-auto w-1.5 h-1.5 rounded-full bg-white animate-pulse"
        />
      )}
    </button>
  );
}

function LoginView({ onLogin }: { onLogin: (user: AppUser) => void }) {
  const [isRegister, setIsRegister] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const initializeAdmin = async () => {
    const adminRef = doc(db, 'app_users', 'admin_node');
    const snap = await getDoc(adminRef);
    if (!snap.exists()) {
      await setDoc(adminRef, {
        username: 'Admin',
        password: '888',
        role: 'admin',
        status: 'approved',
        createdAt: serverTimestamp()
      });
    }
  };

  useEffect(() => {
    initializeAdmin();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      if (isRegister) {
        // Search if exists
        const q = query(collection(db, 'app_users'), where('username', '==', username));
        const snap = await getDocs(q);
        if (!snap.empty) {
          throw new Error('Username already taken');
        }

        await addDoc(collection(db, 'app_users'), {
          username,
          password,
          role: 'user',
          status: 'pending',
          createdAt: serverTimestamp()
        });
        setSuccess('Registration successful. Awaiting admin approval.');
        setIsRegister(false);
      } else {
        const q = query(collection(db, 'app_users'), where('username', '==', username), where('password', '==', password));
        const snap = await getDocs(q);
        
        if (snap.empty) {
          throw new Error('Invalid credentials');
        }

        const userData = snap.docs[0].data() as AppUser;
        if (userData.status !== 'approved') {
          throw new Error('Your account is pending approval by an admin.');
        }

        const userObj = { id: snap.docs[0].id, ...userData };
        localStorage.setItem('ticket_user', JSON.stringify(userObj));
        onLogin(userObj);
      }
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#020617] flex items-center justify-center p-4 relative overflow-hidden font-sans">
      <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-indigo-600/10 rounded-full blur-[120px] -mr-64 -mt-64" />
      <div className="absolute bottom-0 left-0 w-[500px] h-[500px] bg-indigo-900/10 rounded-full blur-[120px] -ml-64 -mb-64" />
      
      <motion.div 
        initial={{ opacity: 0, scale: 0.95 }}
        animate={{ opacity: 1, scale: 1 }}
        className="max-w-md w-full space-y-8 relative z-10"
      >
        <div className="text-center space-y-6">
          <div className="w-20 h-20 bg-indigo-600 rounded-3xl flex items-center justify-center mx-auto shadow-2xl shadow-indigo-500/30 rotate-3">
            <TicketIcon className="w-10 h-10 text-white" />
          </div>
          <div className="space-y-2">
            <h1 className="text-4xl font-extrabold tracking-tight text-white">TicketMaster</h1>
            <p className="text-slate-400 text-lg">Secure Protocol Terminal</p>
          </div>
        </div>

        <form onSubmit={handleSubmit} className="bg-[#0F172A]/50 backdrop-blur-xl border border-[#1E293B] p-8 rounded-[2.5rem] shadow-2xl space-y-5">
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Username</label>
            <input 
              required
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#020617] border border-[#1E293B] rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-white"
              placeholder="Enter credentials..."
            />
          </div>
          <div className="space-y-2">
            <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Password</label>
            <input 
              required
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#020617] border border-[#1E293B] rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-white"
              placeholder="••••••••"
            />
          </div>

          {error && <p className="text-xs text-rose-400 bg-rose-500/10 p-3 rounded-xl border border-rose-500/20">{error}</p>}
          {success && <p className="text-xs text-emerald-400 bg-emerald-500/10 p-3 rounded-xl border border-emerald-500/20">{success}</p>}

          <button 
            type="submit"
            disabled={loading}
            className="w-full bg-white text-slate-950 py-4 rounded-2xl font-bold hover:bg-slate-100 transition-all shadow-xl active:scale-95 disabled:opacity-50"
          >
            {loading ? <Loader2 className="w-5 h-5 animate-spin mx-auto" /> : isRegister ? 'Register Account' : 'Initialize Access'}
          </button>

          <button 
            type="button"
            onClick={() => setIsRegister(!isRegister)}
            className="w-full text-center text-slate-500 text-xs font-bold uppercase tracking-widest hover:text-white transition-colors py-2"
          >
            {isRegister ? 'Already have an account? Login' : 'Request Access Node'}
          </button>
        </form>
      </motion.div>
    </div>
  );
}

function SystemSettingsView({ appearance, music }: { appearance: AppearanceSettings, music: MusicSettings }) {
  const [updating, setUpdating] = useState<string | null>(null);

  const updateAppearance = async (updates: Partial<AppearanceSettings>) => {
    setUpdating('appearance');
    try {
      await setDoc(doc(db, 'settings', 'appearance'), { ...appearance, ...updates }, { merge: true });
    } finally {
      setUpdating(null);
    }
  };

  const updateMusic = async (updates: Partial<MusicSettings>) => {
    setUpdating('music');
    try {
      await setDoc(doc(db, 'settings', 'music'), { ...music, ...updates, lastUpdated: serverTimestamp() }, { merge: true });
    } finally {
      setUpdating(null);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.98 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-10 max-w-5xl mx-auto space-y-10"
    >
      <div className="space-y-1">
        <h2 className="text-3xl font-extrabold text-white">Terminal Config</h2>
        <p className="text-slate-500 text-sm">System-wide appearance override and global audio broadcast.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Appearance Control */}
        <div className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 space-y-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600/10 rounded-2xl flex items-center justify-center">
              <Palette className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h3 className="font-bold text-white uppercase tracking-wider text-sm">Visual Protocol</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Interface Branding</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Primary Signature Color</label>
              <div className="flex gap-4 items-center">
                <input 
                  type="color" 
                  value={appearance.primaryColor}
                  onChange={(e) => updateAppearance({ primaryColor: e.target.value })}
                  className="w-12 h-12 rounded-xl border-none cursor-pointer bg-transparent"
                />
                <input 
                  type="text"
                  value={appearance.primaryColor}
                  onChange={(e) => updateAppearance({ primaryColor: e.target.value })}
                  className="flex-1 bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs font-mono lowercase focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />
              </div>
            </div>

            <div className="space-y-3">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Accent Signature Color</label>
              <div className="flex gap-4 items-center">
                <input 
                  type="color" 
                  value={appearance.accentColor}
                  onChange={(e) => updateAppearance({ accentColor: e.target.value })}
                  className="w-12 h-12 rounded-xl border-none cursor-pointer bg-transparent"
                />
                <input 
                  type="text"
                  value={appearance.accentColor}
                  onChange={(e) => updateAppearance({ accentColor: e.target.value })}
                  className="flex-1 bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs font-mono lowercase focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4 pt-4">
              <button 
                onClick={() => updateAppearance({ primaryColor: '#6366f1', accentColor: '#4f46e5' })}
                className="py-3 bg-indigo-600/10 border border-indigo-500/20 rounded-xl text-[10px] font-black uppercase tracking-tighter text-indigo-400 hover:bg-indigo-600/20 transition-all"
              >
                Reset Default
              </button>
              <button 
                onClick={() => updateAppearance({ primaryColor: '#f43f5e', accentColor: '#e11d48' })}
                className="py-3 bg-rose-500/10 border border-rose-500/20 rounded-xl text-[10px] font-black uppercase tracking-tighter text-rose-400 hover:bg-rose-500/20 transition-all"
              >
                Winter Red
              </button>
            </div>
          </div>
        </div>

        {/* Audio Broadcast Control */}
        <div className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 space-y-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-indigo-600/10 rounded-2xl flex items-center justify-center">
              <Music className="w-6 h-6 text-indigo-400" />
            </div>
            <div>
              <h3 className="font-bold text-white uppercase tracking-wider text-sm">Global Broadcast</h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Real-time Audio Sync</p>
            </div>
          </div>

          <div className="space-y-6">
            <div className="space-y-3">
              <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Media Stream Source (YouTube)</label>
              <div className="relative">
                <input 
                  type="text"
                  placeholder="Paste URL or type song name..."
                  value={music.url}
                  onChange={(e) => updateMusic({ url: e.target.value })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl pl-4 pr-12 py-4 text-xs font-mono focus:outline-none focus:ring-2 focus:ring-indigo-500/30"
                />
                {!music.url.startsWith('http') && music.url.length > 0 ? (
                  <button 
                    onClick={() => window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(music.url)}`, '_blank')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-500/10 rounded-lg text-indigo-400 hover:bg-indigo-500/20 transition-all text-[10px] font-bold uppercase tracking-widest"
                  >
                    Search
                  </button>
                ) : (
                  <button 
                    onClick={() => updateMusic({ url: '', playing: false })}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-2 bg-indigo-500/10 rounded-lg text-indigo-400 hover:bg-rose-500/10 hover:text-rose-400 transition-colors"
                  >
                    <SkipForward className="w-4 h-4" />
                  </button>
                )}
              </div>
              <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest px-1">Tip: Type a song name and click Search to find a link on YouTube</p>
            </div>

            <div className="flex items-center justify-between p-5 bg-[#020617] rounded-2xl border border-[#1E293B]">
              <div className="space-y-1">
                <span className="text-[10px] font-bold uppercase tracking-widest text-slate-500">Global Playback</span>
                <p className="text-xs text-white font-bold">{music.playing ? 'BROADCASTING' : 'SUSPENDED'}</p>
              </div>
              <button 
                onClick={() => updateMusic({ playing: !music.playing })}
                className={`w-14 h-14 rounded-2xl flex items-center justify-center transition-all ${music.playing ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-500/30' : 'bg-slate-800 text-slate-500 hover:bg-slate-700'}`}
              >
                {music.playing ? <Pause className="w-6 h-6" /> : <Play className="w-6 h-6" />}
              </button>
            </div>

            <div className="space-y-3">
              <div className="flex justify-between items-center px-1">
                <label className="text-[11px] font-bold text-slate-500 uppercase tracking-widest">System Gain</label>
                <span className="text-[10px] font-mono text-indigo-400 uppercase font-black">{Math.round(music.volume * 100)}%</span>
              </div>
              <input 
                type="range"
                min="0"
                max="1"
                step="0.01"
                value={music.volume}
                onChange={(e) => updateMusic({ volume: parseFloat(e.target.value) })}
                className="w-full h-2 bg-[#020617] border border-[#1E293B] rounded-full appearance-none cursor-pointer accent-indigo-500"
              />
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function VoiceConsoleView() {
  const [guilds, setGuilds] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [members, setMembers] = useState<any[]>([]);
  const [selectedGuild, setSelectedGuild] = useState('');
  const [selectedChannel, setSelectedChannel] = useState('');
  const [isConnected, setIsConnected] = useState(false);
  const [isMicOn, setIsMicOn] = useState(false);
  const [status, setStatus] = useState('');
  const [ws, setWs] = useState<WebSocket | null>(null);
  const [audioStream, setAudioStream] = useState<MediaStream | null>(null);
  const [audioContext, setAudioContext] = useState<AudioContext | null>(null);
  const [playbackContext, setPlaybackContext] = useState<AudioContext | null>(null);
  const [analyser, setAnalyser] = useState<AnalyserNode | null>(null);
  const [audioLevel, setAudioLevel] = useState(0);

  useEffect(() => {
    fetch('/api/bot/guilds').then(res => res.json()).then(data => setGuilds(Array.isArray(data) ? data : [])).catch(() => {});
    
    return () => {
      ws?.close();
      audioStream?.getTracks().forEach(t => t.stop());
      playbackContext?.close();
    };
  }, []);

  const fetchMembers = (guildId: string, channelId: string) => {
    fetch(`/api/bot/guilds/${guildId}/voice-channels/${channelId}/members`)
      .then(res => res.json())
      .then(data => setMembers(Array.isArray(data) ? data : []))
      .catch(() => setMembers([]));
  };

  useEffect(() => {
    if (selectedGuild) {
      fetch(`/api/bot/guilds/${selectedGuild}/voice-channels`)
        .then(res => res.json())
        .then(data => setChannels(Array.isArray(data) ? data : []))
        .catch(() => setChannels([]));
    } else {
      setChannels([]);
      setMembers([]);
    }
  }, [selectedGuild]);

  useEffect(() => {
    if (selectedGuild && selectedChannel) {
      fetchMembers(selectedGuild, selectedChannel);
    }
  }, [selectedGuild, selectedChannel]);

  const connect = async () => {
    if (!selectedGuild || !selectedChannel) return;
    setStatus('Connecting...');
    try {
      const res = await fetch('/api/bot/voice/join', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId: selectedGuild, channelId: selectedChannel })
      });
      const data = await res.json();
      if (data.status === 'joined') {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
        const socket = new WebSocket(`${protocol}//${window.location.host}`);
        socket.binaryType = 'arraybuffer';
        
        const pbCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 48000 });
        setPlaybackContext(pbCtx);
        const userTimelines = new Map<string, number>();

        socket.onopen = () => {
          socket.send(JSON.stringify({ type: 'init', guildId: selectedGuild }));
          setIsConnected(true);
          setStatus('Connected to voice channel');
        };

        socket.onmessage = async (event) => {
          if (typeof event.data === 'string') {
            const msg = JSON.parse(event.data);
            if (msg.type === 'voice_update' && msg.channelId === selectedChannel) {
              fetchMembers(selectedGuild, selectedChannel);
            }
            return;
          }

          // Handle audio data (Binary PCM from Discord)
          // Format: [userIdLength (1 byte)][userId string][audio data (PCM 16-bit 48kHz)]
          const fullBuffer: ArrayBuffer = event.data;
          if (fullBuffer.byteLength < 2) return;
          
          const view = new DataView(fullBuffer);
          const userIdLen = view.getUint8(0);
          if (fullBuffer.byteLength < 1 + userIdLen) return;
          
          const userId = new TextDecoder().decode(fullBuffer.slice(1, 1 + userIdLen));
          const audioPart = fullBuffer.slice(1 + userIdLen);
          
          if (audioPart.byteLength % 4 !== 0) return; 
          
          const int16Array = new Int16Array(audioPart);
          const numFrames = int16Array.length / 2;
          if (numFrames === 0) return;

          const audioBuffer = pbCtx.createBuffer(2, numFrames, 48000);
          const leftChannel = audioBuffer.getChannelData(0);
          const rightChannel = audioBuffer.getChannelData(1);

          for (let i = 0; i < numFrames; i++) {
            leftChannel[i] = int16Array[i * 2] / 32768.0;
            rightChannel[i] = int16Array[i * 2 + 1] / 32768.0;
          }

          const source = pbCtx.createBufferSource();
          source.buffer = audioBuffer;
          
          // Connect to compressor/limiter if needed, but for now just output
          source.connect(pbCtx.destination);
          
          // Schedule playback per user to avoid overlaps/gaps
          const now = pbCtx.currentTime;
          let nextStartTime = userTimelines.get(userId) || (now + 0.2);
          
          // If we're behind, resync with a safe buffer
          if (nextStartTime < now) {
            nextStartTime = now + 0.2; 
          }
          
          source.start(nextStartTime);
          userTimelines.set(userId, nextStartTime + audioBuffer.duration);
        };
        
        setWs(socket);
      } else {
        setStatus(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setStatus(`Error: ${err.message}`);
    }
  };

  const disconnect = async () => {
    if (!selectedGuild) return;
    try {
      await fetch('/api/bot/voice/leave', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId: selectedGuild })
      });
      ws?.close();
      setWs(null);
      setIsConnected(false);
      toggleMic(false);
      setStatus('Disconnected');
    } catch (err) {}
  };

  const toggleMic = async (on: boolean) => {
    if (on) {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ audio: true, video: false });
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 48000 });
        const source = ctx.createMediaStreamSource(stream);
        const analyzerNode = ctx.createAnalyser();
        analyzerNode.fftSize = 256;
        source.connect(analyzerNode);
        
        const scriptNode = ctx.createScriptProcessor(4096, 1, 1);
        source.connect(scriptNode);
        scriptNode.connect(ctx.destination);
        
        scriptNode.onaudioprocess = (e) => {
          if (ws?.readyState === WebSocket.OPEN) {
            const inputData = e.inputBuffer.getChannelData(0);
            const pcmData = new Int16Array(inputData.length);
            for (let i = 0; i < inputData.length; i++) {
              pcmData[i] = Math.max(-1, Math.min(1, inputData[i])) * 0x7FFF;
            }
            ws.send(pcmData.buffer);
          }
        };

        setAudioStream(stream);
        setAudioContext(ctx);
        setAnalyser(analyzerNode);
        setIsMicOn(true);
      } catch (err: any) {
        setStatus(`Mic Error: ${err.message}`);
      }
    } else {
      audioStream?.getTracks().forEach(t => t.stop());
      audioContext?.close();
      setAudioStream(null);
      setAudioContext(null);
      setAnalyser(null);
      setIsMicOn(false);
      setAudioLevel(0);
    }
  };

  useEffect(() => {
    if (!analyser || !isMicOn) return;
    let anim: number;
    const update = () => {
      const data = new Uint8Array(analyser.frequencyBinCount);
      analyser.getByteFrequencyData(data);
      const avg = data.reduce((a, b) => a + b) / data.length;
      setAudioLevel(avg);
      anim = requestAnimationFrame(update);
    };
    update();
    return () => cancelAnimationFrame(anim);
  }, [analyser, isMicOn]);

  return (
    <motion.div 
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      className="p-10 max-w-4xl mx-auto h-full flex flex-col"
    >
      <div className="flex justify-between items-center mb-10">
        <div className="space-y-1">
          <h2 className="text-3xl font-extrabold text-white">Voice Terminal</h2>
          <p className="text-slate-500 text-sm">Join channels and broadcast your mic through the bot.</p>
        </div>
        {isConnected && (
           <div className="flex items-center gap-2 bg-emerald-500/10 text-emerald-400 px-4 py-2 rounded-full border border-emerald-500/20 text-xs font-bold animate-pulse">
             <div className="w-2 h-2 rounded-full bg-emerald-400" />
             LIVE: {channels.find(c => c.id === selectedChannel)?.name}
           </div>
        )}
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 flex-1 overflow-hidden">
        <div className="space-y-6 flex flex-col overflow-hidden">
          <section className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 space-y-6">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Connection Setup</h3>
            <div className="space-y-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Server</label>
                <select 
                  value={selectedGuild}
                  onChange={(e) => setSelectedGuild(e.target.value)}
                  disabled={isConnected}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                >
                  <option value="">Select Server</option>
                  {guilds.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Voice Channel</label>
                <select 
                  value={selectedChannel}
                  onChange={(e) => setSelectedChannel(e.target.value)}
                  disabled={isConnected || !selectedGuild}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                >
                  <option value="">Select Channel</option>
                  {channels.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
            </div>

            {!isConnected ? (
              <button 
                onClick={connect}
                disabled={!selectedChannel}
                className="w-full bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-indigo-500/20 disabled:opacity-50 transition-all active:scale-95"
              >
                <Phone className="w-5 h-5" />
                Join Room
              </button>
            ) : (
              <div className="space-y-4">
                <button 
                  onClick={disconnect}
                  className="w-full bg-rose-600 hover:bg-rose-500 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 shadow-xl shadow-rose-500/20 transition-all active:scale-95"
                >
                  <PhoneOff className="w-5 h-5" />
                  Disconnect
                </button>

                <div className="h-px bg-slate-800 my-4" />

                <div className="space-y-4 pt-2">
                  <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Music Player</h3>
                  <div className="space-y-2 text-left">
                     <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">YouTube / Audio URL</label>
                     <div className="flex gap-2">
                        <input 
                          type="text" 
                          id="music-url-input"
                          placeholder="Paste link here..."
                          className="flex-1 bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                        />
                        <button 
                          onClick={async () => {
                            const url = (document.getElementById('music-url-input') as HTMLInputElement).value;
                            if (!url) return;
                            setStatus('Playing music...');
                            const res = await fetch('/api/bot/voice/play-music', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ guildId: selectedGuild, url })
                            });
                            const data = await res.json();
                            if (res.ok) setStatus(`Playing: ${url}`);
                            else setStatus(`Error: ${data.error}`);
                          }}
                          className="bg-indigo-600 hover:bg-indigo-500 p-3 rounded-xl text-white transition-all active:scale-95"
                        >
                          <Play className="w-4 h-4" />
                        </button>
                        <button 
                          onClick={async () => {
                            setStatus('Stopping music...');
                            const res = await fetch('/api/bot/voice/stop-music', {
                              method: 'POST',
                              headers: { 'Content-Type': 'application/json' },
                              body: JSON.stringify({ guildId: selectedGuild })
                            });
                            if (res.ok) setStatus('Music stopped');
                          }}
                          className="bg-rose-600 hover:bg-rose-500 p-3 rounded-xl text-white transition-all active:scale-95"
                        >
                          <XCircle className="w-4 h-4" />
                        </button>
                     </div>
                  </div>
                </div>
              </div>
            )}
          </section>

          <section className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 flex-1 flex flex-col min-h-0 overflow-hidden">
             <div className="flex justify-between items-center mb-6">
                <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Room Members ({members.length})</h3>
                <motion.button 
                  whileHover={{ rotate: 180 }}
                  onClick={() => selectedGuild && selectedChannel && fetchMembers(selectedGuild, selectedChannel)}
                  className="text-slate-500 hover:text-indigo-400 p-1"
                >
                  <RotateCcw className="w-3 h-3" />
                </motion.button>
             </div>
             <div className="space-y-3 overflow-y-auto pr-2 custom-scrollbar flex-1">
                {members.length === 0 ? (
                  <p className="text-[10px] text-slate-600 font-medium italic text-center py-4">No members in channel.</p>
                ) : (
                  members.map(m => (
                    <div key={m.id} className="flex items-center justify-between p-3 bg-[#020617]/50 rounded-xl border border-[#1E293B] group hover:border-indigo-500/30 transition-all">
                      <div className="flex items-center gap-3">
                        <div className="relative">
                          <img src={m.avatar} alt={m.name} className="w-8 h-8 rounded-full border border-[#1E293B]" />
                          <div className={`absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full border-2 border-[#020617] ${m.mute ? 'bg-rose-500' : 'bg-emerald-500'}`} />
                        </div>
                        <div className="space-y-0.5">
                          <p className="text-xs font-bold text-white group-hover:text-indigo-400 transition-colors">{m.name}</p>
                          <div className="flex gap-1">
                            {m.deaf && <span className="text-[8px] bg-rose-500/10 text-rose-400 px-1 rounded font-black italic uppercase">Deafened</span>}
                            {m.mute && <span className="text-[8px] bg-rose-500/10 text-rose-400 px-1 rounded font-black italic uppercase">Muted</span>}
                          </div>
                        </div>
                      </div>
                      <div className="flex gap-1.5 opacity-40 group-hover:opacity-100 transition-opacity">
                         {!m.mute ? <Mic className="w-3 h-3 text-emerald-400" /> : <MicOff className="w-3 h-3 text-rose-400" />}
                      </div>
                    </div>
                  ))
                )}
             </div>
          </section>

          {status && (
            <div className={`p-4 rounded-2xl border text-xs font-bold ${status.startsWith('Error') || status.startsWith('Mic Error') ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-indigo-500/10 border-indigo-500/20 text-indigo-400'}`}>
              {status}
            </div>
          )}
        </div>

        <div className="flex flex-col gap-6">
          <section className={`flex-1 bg-[#1E293B]/20 border ${isConnected ? 'border-indigo-500/50' : 'border-[#1E293B]'} rounded-[2.5rem] p-8 flex flex-col items-center justify-center gap-8 transition-all`}>
             <div className="relative">
                <div 
                  className="absolute inset-0 rounded-full bg-indigo-500/20 blur-xl transition-all duration-75"
                  style={{ transform: `scale(${1 + audioLevel / 100})`, opacity: isMicOn ? 1 : 0 }}
                />
                <button 
                  onClick={() => toggleMic(!isMicOn)}
                  disabled={!isConnected}
                  className={`relative w-24 h-24 rounded-full flex items-center justify-center transition-all active:scale-90 disabled:opacity-30 ${isMicOn ? 'bg-indigo-600 shadow-2xl shadow-indigo-500' : 'bg-slate-800 hover:bg-slate-700'}`}
                >
                  {isMicOn ? <Mic className="w-10 h-10 text-white" /> : <MicOff className="w-10 h-10 text-slate-500" />}
                </button>
             </div>

             <div className="text-center space-y-2">
                <p className={`text-sm font-bold tracking-tight ${isMicOn ? 'text-indigo-400' : 'text-slate-500'}`}>
                  {isMicOn ? 'Streaming Audio...' : 'Microphone Muted'}
                </p>
                <p className="text-[10px] font-black uppercase tracking-widest text-slate-600">
                  {isConnected ? 'Press to talk or toggle' : 'Join a room to enable mic'}
                </p>
             </div>

             <div className="flex items-end gap-1 h-8">
                {[...Array(12)].map((_, i) => (
                  <div 
                    key={i} 
                    className="w-1.5 bg-indigo-500 rounded-full transition-all duration-75"
                    style={{ 
                      height: `${isMicOn ? Math.max(10, Math.random() * audioLevel * 1.5) : 5}%`,
                      opacity: isMicOn ? 0.8 : 0.2
                    }}
                  />
                ))}
             </div>
          </section>

          <div className="p-6 bg-amber-500/10 border border-amber-500/20 rounded-3xl space-y-2">
             <div className="flex items-center gap-2 text-amber-500 text-xs font-black uppercase tracking-widest">
               ⚡ Requirements
             </div>
             <ul className="text-[10px] text-slate-400 space-y-1 font-medium leading-relaxed">
               <li>• Bot needs `Connect` and `Speak` permissions</li>
               <li>• Browser microphone permission required</li>
               <li>• High-speed connection recommended for low latency</li>
             </ul>
          </div>
        </div>
      </div>
    </motion.div>
  );
}

function TicketConfigView() {
  const [config, setConfig] = useState({
    guildId: '',
    channelId: '',
    embed: {
      title: 'Support Panel',
      description: 'Click below to open a ticket',
      color: '#6366f1',
      image: '',
      thumbnail: '',
      footer: 'TicketMaster Bot'
    },
    buttons: [
      { label: 'Support', categoryId: '', emoji: '🎫' }
    ],
    staffRoleId: ''
  });

  const [guilds, setGuilds] = useState<any[]>([]);
  const [channels, setChannels] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [roles, setRoles] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState('');

  useEffect(() => {
    fetch('/api/bot/guilds')
      .then(res => res.json())
      .then(data => Array.isArray(data) ? setGuilds(data) : setGuilds([]))
      .catch((err) => {
        console.error('Fetch guilds failed:', err);
        setGuilds([]);
      });
    
    // Load existing config from Firestore
    getDoc(doc(db, 'settings', 'ticket_config')).then(snap => {
      if (snap.exists()) setConfig({ ...config, ...snap.data() as any });
    });
  }, []);

  useEffect(() => {
    if (config.guildId) {
      fetch(`/api/bot/guilds/${config.guildId}/channels`)
        .then(res => res.json())
        .then(data => Array.isArray(data) ? setChannels(data) : setChannels([]))
        .catch(() => setChannels([]));

      fetch(`/api/bot/guilds/${config.guildId}/categories`)
        .then(res => res.json())
        .then(data => Array.isArray(data) ? setCategories(data) : setCategories([]))
        .catch(() => setCategories([]));

      fetch(`/api/bot/guilds/${config.guildId}/roles`)
        .then(res => res.json())
        .then(data => Array.isArray(data) ? setRoles(data) : setRoles([]))
        .catch(() => setRoles([]));
    } else {
      setChannels([]);
      setCategories([]);
      setRoles([]);
    }
  }, [config.guildId]);

  const handleSend = async () => {
    setLoading(true);
    setStatus('');
    try {
      const res = await fetch('/api/guilds/setup-dynamic-panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...config,
          embed: {
            ...config.embed,
            color: parseInt(config.embed.color.replace('#', ''), 16)
          }
        })
      });
      const data = await res.json();
      if (data.status === 'success') {
        setStatus('Panel sent successfully!');
        await setDoc(doc(db, 'settings', 'ticket_config'), config);
      } else {
        setStatus(`Error: ${data.error}`);
      }
    } catch (err: any) {
      setStatus(`Error: ${err.message}`);
    } finally {
      setLoading(false);
    }
  };

  const addButton = () => {
    setConfig({
      ...config,
      buttons: [...config.buttons, { label: 'New Ticket', categoryId: '', emoji: '➕' }]
    });
  };

  const updateButton = (index: number, updates: any) => {
    const newButtons = [...config.buttons];
    newButtons[index] = { ...newButtons[index], ...updates };
    setConfig({ ...config, buttons: newButtons });
  };

  const removeButton = (index: number) => {
    setConfig({
      ...config,
      buttons: config.buttons.filter((_, i) => i !== index)
    });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-10 max-w-6xl mx-auto space-y-10"
    >
      <div className="flex justify-between items-end">
        <div className="space-y-1">
          <h2 className="text-3xl font-extrabold text-white">PV Ticket Config</h2>
          <p className="text-slate-500 text-sm">Design and deploy your custom ticket interaction panel.</p>
        </div>
        <button 
          onClick={handleSend}
          disabled={loading || !config.guildId || !config.channelId}
          className="bg-indigo-600 hover:bg-indigo-500 text-white px-8 py-3 rounded-2xl font-bold flex items-center gap-3 shadow-xl shadow-indigo-500/20 disabled:opacity-50 transition-all active:scale-95"
        >
          {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Send className="w-5 h-5" />}
          Deploy Panel
        </button>
      </div>

      {status && (
        <div className={`p-4 rounded-2xl border text-sm font-bold ${status.startsWith('Error') ? 'bg-rose-500/10 border-rose-500/20 text-rose-400' : 'bg-emerald-500/10 border-emerald-500/20 text-emerald-400'}`}>
          {status}
        </div>
      )}

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-10">
        <div className="space-y-8">
          <section className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 space-y-6">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Target Configuration</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Server</label>
                <select 
                  value={config.guildId}
                  onChange={(e) => setConfig({ ...config, guildId: e.target.value, channelId: '' })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                >
                  <option value="">Select Guild</option>
                  {guilds.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Target Channel</label>
                <select 
                  value={config.channelId}
                  onChange={(e) => setConfig({ ...config, channelId: e.target.value })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                  disabled={!config.guildId}
                >
                  <option value="">Select Channel</option>
                  {channels.map(c => <option key={c.id} value={c.id}>#{c.name}</option>)}
                </select>
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Staff Role (Delete Permission)</label>
              <select 
                value={config.staffRoleId}
                onChange={(e) => setConfig({ ...config, staffRoleId: e.target.value })}
                className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                disabled={!config.guildId}
              >
                <option value="">Select Staff Role</option>
                {roles.map(r => <option key={r.id} value={r.id} style={{ color: r.color }}>{r.name}</option>)}
              </select>
            </div>
          </section>

          <section className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 space-y-6">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Embed Visuals</h3>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Title</label>
                <input 
                  value={config.embed.title}
                  onChange={(e) => setConfig({ ...config, embed: { ...config.embed, title: e.target.value } })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Brand Color</label>
                <input 
                  type="color"
                  value={config.embed.color}
                  onChange={(e) => setConfig({ ...config, embed: { ...config.embed, color: e.target.value } })}
                  className="w-full h-10 bg-transparent border-none cursor-pointer rounded-xl"
                />
              </div>
            </div>
            <div className="space-y-2">
              <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Description</label>
              <textarea 
                value={config.embed.description}
                onChange={(e) => setConfig({ ...config, embed: { ...config.embed, description: e.target.value } })}
                className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white resize-none"
                rows={3}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Banner URL</label>
                <input 
                  placeholder="https://..."
                  value={config.embed.image}
                  onChange={(e) => setConfig({ ...config, embed: { ...config.embed, image: e.target.value } })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                />
              </div>
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-1">Thumb URL</label>
                <input 
                  placeholder="https://..."
                  value={config.embed.thumbnail}
                  onChange={(e) => setConfig({ ...config, embed: { ...config.embed, thumbnail: e.target.value } })}
                  className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-3 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                />
              </div>
            </div>
          </section>
        </div>

        <section className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] p-8 flex flex-col">
          <div className="flex justify-between items-center mb-6">
            <h3 className="text-xs font-black text-slate-500 uppercase tracking-[0.2em]">Interaction Buttons</h3>
            <button 
              onClick={addButton}
              className="p-2 bg-indigo-500/10 hover:bg-indigo-500/20 rounded-lg text-indigo-400 transition-colors"
            >
              <Plus className="w-4 h-4" />
            </button>
          </div>
          
          <div className="space-y-4 flex-1 overflow-auto max-h-[600px] pr-2 custom-scrollbar">
            {config.buttons.map((btn, idx) => (
              <div key={idx} className="p-5 bg-[#020617]/50 rounded-2xl border border-[#1E293B] space-y-4 relative group">
                <button 
                  onClick={() => removeButton(idx)}
                  className="absolute top-4 right-4 p-1.5 hover:bg-rose-500/10 rounded-lg text-slate-600 hover:text-rose-500 transition-colors opacity-0 group-hover:opacity-100"
                >
                  <XCircle className="w-4 h-4" />
                </button>

                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest pl-1">Label</label>
                    <input 
                      value={btn.label}
                      onChange={(e) => updateButton(idx, { label: e.target.value })}
                      className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest pl-1">Emoji</label>
                    <input 
                      value={btn.emoji}
                      onChange={(e) => updateButton(idx, { emoji: e.target.value })}
                      className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white text-center"
                    />
                  </div>
                </div>
                <div className="space-y-2">
                    <label className="text-[9px] font-bold text-slate-600 uppercase tracking-widest pl-1">Category Target</label>
                    <select 
                      value={btn.categoryId}
                      onChange={(e) => updateButton(idx, { categoryId: e.target.value })}
                      className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-3 py-2 text-xs focus:outline-none focus:ring-2 focus:ring-indigo-500/30 text-white"
                      disabled={!config.guildId}
                    >
                      <option value="">(Root / No Category)</option>
                      {categories.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                    </select>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </motion.div>
  );
}

function UsersManagementView() {
  const [users, setUsers] = useState<AppUser[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const path = 'app_users';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snap) => {
      setUsers(snap.docs.map(d => ({ id: d.id, ...d.data() } as AppUser)));
      setLoading(false);
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
      setLoading(false);
    });
  }, []);

  const handleStatus = async (id: string, status: 'approved' | 'rejected') => {
    await updateDoc(doc(db, 'app_users', id), { status });
  };

  const handleRole = async (id: string, role: 'admin' | 'user') => {
    await updateDoc(doc(db, 'app_users', id), { role });
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      className="p-10 max-w-5xl mx-auto space-y-10"
    >
      <div className="flex items-center justify-between">
        <div className="space-y-1">
          <h2 className="text-3xl font-extrabold text-white">Personnel Control</h2>
          <p className="text-slate-500 text-sm">Authorize or revoke access for system supervisors.</p>
        </div>
        <div className="bg-indigo-600/10 border border-indigo-500/20 px-4 py-2 rounded-xl text-indigo-400 font-bold text-xs uppercase tracking-widest">
          {users.filter(u => u.status === 'pending').length} Pending Node Requests
        </div>
      </div>

      <div className="bg-[#1E293B]/20 border border-[#1E293B] rounded-[2.5rem] overflow-hidden">
        <table className="w-full text-left">
          <thead>
            <tr className="border-b border-[#1E293B] bg-[#020617]/40">
              <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Personnel</th>
              <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Privilege</th>
              <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Status</th>
              <th className="px-8 py-5 text-[10px] font-bold uppercase tracking-[0.2em] text-slate-500">Protocol</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1E293B]">
            {users.map(u => (
              <tr key={u.id} className="hover:bg-[#1E293B]/10 transition-colors group">
                <td className="px-8 py-5">
                  <div className="flex items-center gap-3">
                    <div className="w-9 h-9 bg-slate-800 rounded-xl flex items-center justify-center font-bold text-slate-400">
                      {u.username.charAt(0)}
                    </div>
                    <span className="font-bold text-white">{u.username}</span>
                  </div>
                </td>
                <td className="px-8 py-5">
                  <span className={`px-2 py-1 rounded-md text-[10px] font-bold uppercase tracking-wider ${u.role === 'admin' ? 'bg-indigo-500/10 text-indigo-400' : 'bg-slate-800 text-slate-500'}`}>
                    {u.role}
                  </span>
                </td>
                <td className="px-8 py-5">
                  <div className="flex items-center gap-2">
                    {u.status === 'approved' && <CheckCircle className="w-4 h-4 text-emerald-500" />}
                    {u.status === 'pending' && <Clock className="w-4 h-4 text-amber-500" />}
                    {u.status === 'rejected' && <XCircle className="w-4 h-4 text-rose-500" />}
                    <span className={`text-[10px] uppercase font-black ${
                      u.status === 'approved' ? 'text-emerald-500' : 
                      u.status === 'pending' ? 'text-amber-500' : 'text-rose-500'
                    }`}>
                      {u.status}
                    </span>
                  </div>
                </td>
                <td className="px-8 py-5">
                  {u.id !== 'admin_node' && (
                    <div className="flex gap-2">
                      <button 
                        onClick={() => handleStatus(u.id, 'approved')}
                        title="Approve"
                        className="p-2 hover:bg-emerald-500/10 rounded-lg text-slate-500 hover:text-emerald-500 transition-all opacity-0 group-hover:opacity-100"
                      >
                        <CheckCircle className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleStatus(u.id, 'rejected')}
                        title="Reject"
                        className="p-2 hover:bg-rose-500/10 rounded-lg text-slate-500 hover:text-rose-500 transition-all opacity-0 group-hover:opacity-100"
                      >
                        <XCircle className="w-4 h-4" />
                      </button>
                      <button 
                        onClick={() => handleRole(u.id, u.role === 'admin' ? 'user' : 'admin')}
                        title={u.role === 'admin' ? 'Demote to User' : 'Promote to Admin'}
                        className={`p-2 rounded-lg transition-all opacity-0 group-hover:opacity-100 ${u.role === 'admin' ? 'hover:bg-slate-500/10 text-slate-500' : 'hover:bg-indigo-500/10 text-slate-500 hover:text-indigo-400'}`}
                      >
                        <ShieldCheck className="w-4 h-4" />
                      </button>
                    </div>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </motion.div>
  );
}

function DashboardView({ activeBots, setActiveBots }: any) {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [newToken, setNewToken] = useState('');

  const addBot = async () => {
    if (!newToken) return;
    if (activeBots.length >= 2) {
      setError('Limit of 2 bots reached. Remove one first.');
      return;
    }
    setLoading(true);
    setError('');
    try {
      const res = await fetch('/api/bot/tokens', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ token: newToken }),
      });
      const data = await res.json();
      if (res.ok) {
        setActiveBots([...activeBots, { id: data.id, user: data.user || 'Connected' }]);
        setNewToken('');
      } else {
        setError(data.error);
      }
    } catch (err) {
      setError('Failed to connect to server');
    } finally {
      setLoading(false);
    }
  };

  const removeBot = async (id: string) => {
    if (!confirm('Are you sure you want to remove this bot?')) return;
    try {
      const res = await fetch(`/api/bot/tokens/${id}`, { method: 'DELETE' });
      if (res.ok) {
        setActiveBots(activeBots.filter((b: any) => b.id !== id));
      }
    } catch (err) {
      alert('Failed to remove bot');
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      className="p-10 max-w-5xl mx-auto space-y-10"
    >
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-slate-200">
        <div className="bg-[#1E293B]/40 border border-[#1E293B] rounded-3xl p-8 backdrop-blur-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/5 blur-3xl -mr-16 -mt-16 group-hover:bg-indigo-500/10 transition-colors" />
          <h2 className="text-xl font-bold mb-6 flex items-center gap-3 text-white">
            <div className="p-2 bg-indigo-500/10 rounded-lg">
              <ShieldCheck className="w-5 h-5 text-indigo-400" />
            </div>
            Bot Management (Limit: 2)
          </h2>
          <div className="space-y-6">
            <div className="space-y-2">
              <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-widest pl-1">Discord Bot Token</label>
              <input 
                type="password" 
                value={newToken}
                onChange={(e) => setNewToken(e.target.value)}
                placeholder="MTAyNDkz..."
                className="w-full bg-[#020617] border border-[#1E293B] rounded-2xl px-5 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all font-mono"
              />
            </div>
            {error && (
              <motion.div 
                initial={{ opacity: 0, x: -10 }} 
                animate={{ opacity: 1, x: 0 }}
                className="text-xs text-rose-400 bg-rose-500/10 border border-rose-500/20 p-3 rounded-xl flex items-center gap-2"
              >
                 <div className="w-1 h-1 rounded-full bg-rose-500" />
                 {error}
              </motion.div>
            )}
            <button 
              onClick={addBot}
              disabled={loading || activeBots.length >= 2}
              className="w-full bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white py-3.5 rounded-2xl text-sm font-bold transition-all flex items-center justify-center gap-2 shadow-lg shadow-indigo-500/20 active:scale-[0.98]"
            >
              {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Add New Bot'}
            </button>
          </div>
        </div>

        <div className="bg-[#1E293B]/40 border border-[#1E293B] rounded-3xl p-8 backdrop-blur-sm relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-sky-500/5 blur-3xl -mr-16 -mt-16 group-hover:bg-sky-500/10 transition-colors" />
          <h2 className="text-xl font-bold mb-6 flex items-center gap-3 text-white">
            <div className="p-2 bg-sky-500/10 rounded-lg">
              <Server className="w-5 h-5 text-sky-400" />
            </div>
            Active Instances
          </h2>
          <div className="space-y-3 max-h-[220px] overflow-y-auto pr-2 custom-scrollbar">
            {activeBots.map((bot: any) => (
              <div key={bot.id} className="bg-[#020617] border border-[#1E293B] rounded-xl p-4 flex items-center justify-between group/bot">
                <div className="flex items-center gap-3">
                  <div className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
                  <div>
                    <p className="text-xs font-bold text-white leading-none">{bot.user}</p>
                    <p className="text-[9px] text-slate-500 font-mono mt-1 uppercase tracking-tighter">Instance ID: {bot.id}</p>
                  </div>
                </div>
                <button 
                  onClick={() => removeBot(bot.id)}
                  className="p-2 hover:bg-rose-500/10 rounded-lg text-slate-600 hover:text-rose-500 transition-all opacity-0 group-hover/bot:opacity-100"
                >
                  <LogOut className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
            {activeBots.length === 0 && (
              <div className="text-center py-12 border-2 border-dashed border-[#1E293B] rounded-2xl bg-[#020617]/50">
                <ShieldCheck className="w-10 h-10 text-slate-700 mx-auto mb-3 opacity-20" />
                <p className="text-[10px] font-bold text-slate-600 uppercase tracking-widest leading-relaxed">No active bots found.<br/>Register your Discord token to begin.</p>
              </div>
            )}
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatCard label="Live Bots" value={activeBots.length.toString()} color="indigo" />
        <StatCard label="Health Status" value={activeBots.length > 0 ? "STABLE" : "IDLE"} color={activeBots.length > 0 ? "emerald" : "slate"} />
        <StatCard label="Infrastructure" value="AWS-S3" color="amber" />
      </div>
    </motion.div>
  );
}

function StatCard({ label, value, color }: any) {
  const colors: any = {
    indigo: 'text-indigo-400 bg-indigo-500/10 border-indigo-500/20',
    emerald: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
    amber: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
    rose: 'text-rose-400 bg-rose-500/10 border-rose-500/20',
    slate: 'text-slate-400 bg-slate-500/10 border-slate-500/20'
  };
  
  const colorClasses = colors[color] || colors.indigo;
  const parts = colorClasses.split(' ');

  return (
    <div className={`bg-[#1E293B]/30 border rounded-3xl p-6 shadow-sm ${parts[2]}`}>
      <p className="text-[10px] font-bold text-slate-500 uppercase tracking-[0.2em] mb-2">{label}</p>
      <p className={`text-3xl font-extrabold ${parts[0]}`}>{value}</p>
    </div>
  );
}

interface Channel {
  id: string;
  name: string;
  parentId: string | null;
}

function GuildsView() {
  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [loading, setLoading] = useState(true);
  const [setupGuild, setSetupGuild] = useState<Guild | null>(null);
  const [channels, setChannels] = useState<Channel[]>([]);
  const [loadingChannels, setLoadingChannels] = useState(false);
  const [channelId, setChannelId] = useState('');
  const [settingUp, setSettingUp] = useState(false);
  const [loadingSync, setLoadingSync] = useState<string | null>(null);

  useEffect(() => {
    fetch('/api/bot/guilds')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) setGuilds(data);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const openSetup = async (guild: Guild) => {
    setSetupGuild(guild);
    setLoadingChannels(true);
    setChannelId('');
    try {
      const res = await fetch(`/api/bot/guilds/${guild.id}/channels`);
      const data = await res.json();
      if (Array.isArray(data)) {
        setChannels(data);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoadingChannels(false);
    }
  };

  const handleSetup = async () => {
    if (!setupGuild || !channelId) return;
    setSettingUp(true);
    try {
      const res = await fetch('/api/guilds/setup-panel', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guildId: setupGuild.id, channelId }),
      });
      if (res.ok) {
        alert('Setup panel sent to Discord!');
        setSetupGuild(null);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setSettingUp(false);
    }
  };

  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="p-10 space-y-10"
    >
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-extrabold text-white">Bot Infrastructure</h2>
          <p className="text-slate-500 text-sm mt-1">Manage bot integrations across your active server clusters.</p>
        </div>
      </div>

      {loading ? (
        <div className="flex justify-center p-12">
          <Loader2 className="w-10 h-10 animate-spin text-indigo-500" />
        </div>
      ) : (
        <div className="space-y-12">
          {Object.entries(
            guilds.reduce((acc: any, g: any) => {
              const key = g.botTag || 'Unknown Bot';
              if (!acc[key]) acc[key] = [];
              acc[key].push(g);
              return acc;
            }, {})
          ).map(([botTag, botGuilds]: [any, any]) => (
            <div key={botTag} className="space-y-6">
              <div className="flex items-center gap-3">
                <div className="h-px flex-1 bg-slate-800" />
                <span className="text-[10px] font-black text-indigo-400 uppercase tracking-[0.3em] bg-indigo-500/5 px-4 py-1.5 rounded-full border border-indigo-500/10">
                  Bot Node: {botTag}
                </span>
                <div className="h-px flex-1 bg-slate-800" />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {botGuilds.map((guild: any) => (
                  <div key={guild.id} className="bg-[#1E293B]/30 border border-[#1E293B] rounded-3xl p-6 hover:border-indigo-500/50 transition-all group overflow-hidden relative">
                    <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-600/5 blur-3xl -mr-12 -mt-12 group-hover:bg-indigo-600/10 transition-colors" />
                    <div className="flex items-center gap-5 relative z-10">
                      {guild.icon ? (
                        <img src={guild.icon} className="w-14 h-14 rounded-2xl shadow-xl border border-[#1E293B]" alt="" />
                      ) : (
                        <div className="w-14 h-14 bg-indigo-900/20 rounded-2xl flex items-center justify-center font-black text-indigo-400 border border-indigo-500/20">
                          {guild.name.charAt(0)}
                        </div>
                      )}
                      <div className="min-w-0">
                        <h3 className="font-bold text-white group-hover:text-indigo-400 transition-colors truncate">{guild.name}</h3>
                        <p className="text-[10px] font-mono text-slate-500 mt-1 uppercase tracking-tighter">ID: {guild.id}</p>
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-3 mt-6">
                      <button 
                        onClick={() => openSetup(guild)}
                        className="bg-[#020617] hover:bg-slate-800 border border-[#1E293B] text-slate-300 text-[10px] font-bold uppercase tracking-widest py-3 rounded-2xl transition-all relative z-10"
                      >
                        Setup Panel
                      </button>
                      <button 
                        disabled={loadingSync === guild.id}
                        onClick={async () => {
                          const confirmSync = confirm(`Sync all history for ${guild.name}? This might take a while.`);
                          if (!confirmSync) return;
                          setLoadingSync(guild.id);
                          try {
                            const res = await fetch(`/api/bot/guilds/${guild.id}/sync-all-history`, { method: 'POST' });
                            const data = await res.json();
                            alert(`Successfully synced ${data.syncedCount} messages.`);
                          } catch (err) {
                            alert('Sync failed.');
                          } finally {
                            setLoadingSync(null);
                          }
                        }}
                        className="bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/20 text-indigo-400 text-[10px] font-bold uppercase tracking-widest py-3 rounded-2xl transition-all relative z-10 flex items-center justify-center gap-2"
                      >
                        {loadingSync === guild.id ? <Loader2 className="w-3 h-3 animate-spin" /> : 'Sync History'}
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}

          {guilds.length === 0 && (
            <div className="col-span-full py-20 text-center text-slate-500 border-2 border-dashed border-[#1E293B] rounded-[2.5rem] bg-[#1E293B]/5">
              <Server className="w-12 h-12 text-slate-700 mx-auto mb-4" />
              <p className="text-lg font-semibold text-slate-400">No Clusters Detected</p>
              <p className="text-sm">Authorize the bot to at least one server to begin management.</p>
            </div>
          )}
        </div>
      )}

      {/* Setup Modal */}
      <AnimatePresence>
        {setupGuild && (
          <div className="fixed inset-0 bg-[#020617]/80 backdrop-blur-md z-50 flex items-center justify-center p-4">
            <motion.div 
              initial={{ scale: 0.95, opacity: 0, y: 20 }}
              animate={{ scale: 1, opacity: 1, y: 0 }}
              exit={{ scale: 0.95, opacity: 0, y: 20 }}
              className="bg-[#0F172A] border border-[#1E293B] rounded-[2rem] p-10 max-w-lg w-full space-y-8 shadow-[0_32px_64px_-12px_rgba(0,0,0,0.6)]"
            >
              <div className="text-center space-y-2">
                <div className="w-16 h-16 bg-indigo-500/10 rounded-2xl border border-indigo-500/20 flex items-center justify-center mx-auto mb-4">
                   <Hash className="w-8 h-8 text-indigo-400" />
                </div>
                <h3 className="text-2xl font-bold text-white">Select Room Cluster</h3>
                <p className="text-sm text-slate-500 leading-relaxed max-w-[320px] mx-auto">Choose a channel in <span className="text-indigo-400 font-semibold">{setupGuild.name}</span> to deploy the system panel.</p>
              </div>

              <div className="space-y-6">
                <div className="space-y-3">
                  <label className="block text-[11px] font-bold text-slate-500 uppercase tracking-[0.2em] pl-1">Target Communication Port</label>
                  {loadingChannels ? (
                    <div className="flex items-center justify-center p-6 bg-[#020617] rounded-2xl border border-[#1E293B]">
                       <Loader2 className="w-5 h-5 animate-spin text-indigo-500" />
                    </div>
                  ) : (
                    <select 
                      value={channelId}
                      onChange={(e) => setChannelId(e.target.value)}
                      className="w-full bg-[#020617] border border-[#1E293B] rounded-2xl px-5 py-4 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/30 transition-all text-indigo-200 appearance-none cursor-pointer"
                    >
                      <option value="">Select a channel...</option>
                      {channels.map(ch => (
                        <option key={ch.id} value={ch.id}># {ch.name}</option>
                      ))}
                    </select>
                  )}
                </div>
                
                <div className="flex gap-4 pt-4">
                  <button 
                    onClick={() => setSetupGuild(null)}
                    className="flex-1 px-4 py-3.5 bg-[#1E293B]/20 hover:bg-[#1E293B]/40 border border-[#1E293B] rounded-2xl text-xs font-bold uppercase tracking-widest text-slate-400 transition-all"
                  >
                    Discard
                  </button>
                  <button 
                    onClick={handleSetup}
                    disabled={settingUp || !channelId}
                    className="flex-1 px-4 py-3.5 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 border border-indigo-500 shadow-lg shadow-indigo-600/20 rounded-2xl text-xs font-bold uppercase tracking-widest text-white transition-all flex items-center justify-center gap-2"
                  >
                    {settingUp ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Deploy Signal'}
                  </button>
                </div>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}

function TicketsView() {
  const [viewMode, setViewMode] = useState<'tickets' | 'channels' | 'history'>('tickets');
  const [tickets, setTickets] = useState<Ticket[]>([]);
  const [guilds, setGuilds] = useState<Guild[]>([]);
  const [selectedGuildId, setSelectedGuildId] = useState<string>('');
  const [serverChannels, setServerChannels] = useState<Channel[]>([]);
  const [historyResults, setHistoryResults] = useState<any[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTicket, setActiveTicket] = useState<any | null>(null);
  const [activeChannel, setActiveChannel] = useState<Channel | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [sending, setSending] = useState(false);

  useEffect(() => {
    const path = 'tickets';
    const q = query(collection(db, path), orderBy('createdAt', 'desc'));
    return onSnapshot(q, (snapshot) => {
      setTickets(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Ticket)));
    }, (error) => {
      handleFirestoreError(error, OperationType.GET, path);
    });
  }, []);

  useEffect(() => {
    fetch('/api/bot/guilds')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setGuilds(data);
          if (data.length > 0 && !selectedGuildId) setSelectedGuildId(data[0].id);
        }
      });
  }, []);

  useEffect(() => {
    if (selectedGuildId && viewMode === 'channels') {
      fetch(`/api/bot/guilds/${selectedGuildId}/channels`)
        .then(res => res.json())
        .then(data => {
          if (Array.isArray(data)) setServerChannels(data);
        });
    }
  }, [selectedGuildId, viewMode]);

  const searchHistory = async (val: string) => {
    setSearchQuery(val);
    if (val.length < 2) return;
    try {
      const res = await fetch(`/api/bot/search-logs?query=${val}`);
      const data = await res.json();
      setHistoryResults(data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    if (activeTicket) {
      const path = `tickets/${activeTicket.id}/messages`;
      const q = query(collection(db, path), orderBy('createdAt', 'asc'));
      return onSnapshot(q, (snapshot) => {
        setMessages(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      }, (error) => {
        handleFirestoreError(error, OperationType.GET, path);
      });
    } else if (activeChannel) {
      const path = 'global_logs';
      const q = query(
        collection(db, path), 
        where('channelId', '==', activeChannel.id),
        orderBy('createdAt', 'asc'),
        limit(100)
      );
      return onSnapshot(q, (snapshot) => {
        setMessages(snapshot.docs.map(doc => ({ 
          id: doc.id, 
          ...doc.data(),
          source: (doc.data() as any).source || 'discord'
        })));
      }, (error) => {
        handleFirestoreError(error, OperationType.GET, path);
      });
    } else {
      setMessages([]);
    }
  }, [activeTicket, activeChannel]);

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    const content = newMessage.trim();
    if (!content || sending) return;
    
    setSending(true);
    try {
      const channelId = activeTicket ? activeTicket.channelId : activeChannel?.id;
      const guildId = activeTicket ? activeTicket.guildId : (activeChannel as any)?.guildId;
      if (!channelId) return;

      await fetch('/api/tickets/respond', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ channelId, content, guildId })
      });

      const userStr = localStorage.getItem('ticket_user');
      const currentUser = userStr ? JSON.parse(userStr) : { id: 'admin', username: 'Admin' };

      if (activeTicket) {
        await addDoc(collection(db, `tickets/${activeTicket.id}/messages`), {
          ticketId: activeTicket.id,
          authorId: currentUser.id,
          authorName: currentUser.username,
          content,
          source: 'web',
          createdAt: serverTimestamp()
        });
      } else if (activeChannel) {
        await addDoc(collection(db, 'global_logs'), {
          guildId: selectedGuildId || (activeChannel as any).guildId,
          channelId: activeChannel.id,
          channelName: activeChannel.name,
          authorId: currentUser.id,
          authorName: currentUser.username,
          content,
          source: 'web',
          createdAt: serverTimestamp()
        });
      }

      setNewMessage('');
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  const closeTicket = async () => {
    if (!activeTicket || sending) return;
    setSending(true);
    try {
      await updateDoc(doc(db, 'tickets', activeTicket.id), {
        status: 'closed',
        closedAt: serverTimestamp()
      });
      
      await fetch('/api/tickets/close', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          ticketId: activeTicket.id,
          channelId: activeTicket.channelId,
          guildId: activeTicket.guildId
        })
      });
      setActiveTicket(null);
    } catch (err) {
      console.error(err);
    } finally {
      setSending(false);
    }
  };

  return (
    <div className="flex h-full bg-[#0F172A] relative">
      <div className="w-[340px] border-r border-[#1E293B] flex flex-col bg-[#020617]/40 backdrop-blur-sm">
        <div className="p-6 border-b border-[#1E293B] space-y-4">
          <div className="flex bg-[#020617] p-1 rounded-xl border border-[#1E293B]">
             <button 
              onClick={() => { setViewMode('tickets'); setActiveChannel(null); setSearchQuery(''); }}
              className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${viewMode === 'tickets' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
             >
               Tickets
             </button>
             <button 
              onClick={() => { setViewMode('channels'); setActiveTicket(null); setSearchQuery(''); }}
              className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${viewMode === 'channels' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
             >
               Server
             </button>
             <button 
              onClick={() => { setViewMode('history'); setActiveTicket(null); setSearchQuery(''); }}
              className={`flex-1 py-2 text-[9px] font-bold uppercase tracking-widest rounded-lg transition-all ${viewMode === 'history' ? 'bg-indigo-600 text-white shadow-lg' : 'text-slate-500 hover:text-slate-300'}`}
             >
               History
             </button>
          </div>
          
          {viewMode === 'channels' && (
            <select 
              value={selectedGuildId} 
              onChange={(e) => setSelectedGuildId(e.target.value)}
              className="w-full bg-[#020617] border border-[#1E293B] rounded-xl px-4 py-2 text-[11px] font-bold text-indigo-400 focus:outline-none appearance-none cursor-pointer"
            >
              {guilds.map(g => <option key={g.id} value={g.id}>{g.name}</option>)}
            </select>
          )}

          <div className="relative">
            <Search className="w-3.5 h-3.5 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-600" />
            <input 
              value={searchQuery}
              onChange={(e) => viewMode === 'history' ? searchHistory(e.target.value) : setSearchQuery(e.target.value)}
              className="w-full bg-[#020617] border border-[#1E293B] rounded-xl pl-10 pr-4 py-2.5 text-[11px] font-bold uppercase tracking-wider focus:outline-none focus:border-indigo-500/30 transition-all text-white placeholder:text-slate-700" 
              placeholder={viewMode === 'history' ? "Search for rooms..." : "Filter results..."}
            />
          </div>
        </div>

        <div className="flex-1 overflow-auto bg-[#020617]/20 custom-scrollbar">
          {viewMode === 'history' ? (
            historyResults.map(ch => (
              <button 
                key={ch.id}
                onClick={() => { setActiveChannel(ch); setActiveTicket(null); }}
                className={`w-full text-left p-6 transition-all relative border-b border-[#1E293B]/50 ${activeChannel?.id === ch.id ? 'bg-indigo-600/10' : 'hover:bg-[#1E293B]/20'}`}
              >
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-slate-800/50 rounded-lg">
                    <Hash className={`w-4 h-4 ${activeChannel?.id === ch.id ? 'text-indigo-400' : 'text-slate-600'}`} />
                  </div>
                  <div className="min-w-0">
                    <span className={`font-bold text-sm truncate block ${activeChannel?.id === ch.id ? 'text-indigo-400' : 'text-slate-200'}`}>{ch.name}</span>
                    <span className="text-[9px] font-mono text-slate-600">ID: {ch.id}</span>
                  </div>
                </div>
              </button>
            ))
          ) : viewMode === 'tickets' ? (
            tickets.filter(t => t.userName.toLowerCase().includes(searchQuery.toLowerCase())).map(ticket => (
              <button 
                key={ticket.id}
                onClick={() => { setActiveTicket(ticket); setActiveChannel(null); }}
                className={`w-full text-left p-6 transition-all relative group border-b border-[#1E293B]/50 ${activeTicket?.id === ticket.id ? 'bg-indigo-600/10' : 'hover:bg-[#1E293B]/20'}`}
              >
                <div className="flex justify-between items-start mb-2">
                  <span className={`font-bold text-sm truncate ${activeTicket?.id === ticket.id ? 'text-indigo-400' : 'text-slate-200'}`}>{ticket.userName}</span>
                  <span className="text-[9px] font-mono text-slate-600 uppercase tracking-tighter bg-[#020617] px-1.5 py-0.5 rounded border border-[#1E293B]">{ticket.id.slice(0, 8)}</span>
                </div>
                <div className="flex items-center gap-3">
                  <div className={`w-1.5 h-1.5 rounded-full ${ticket.status === 'open' ? 'bg-emerald-500 shadow-[0_0_8px_rgba(16,185,129,0.5)]' : 'bg-slate-700'}`} />
                  <span className="text-[10px] uppercase font-bold text-slate-500">{ticket.status} ticket</span>
                </div>
              </button>
            ))
          ) : (
            serverChannels.filter(c => c.name.toLowerCase().includes(searchQuery.toLowerCase())).map(channel => (
              <button 
                key={channel.id}
                onClick={() => { setActiveChannel(channel); setActiveTicket(null); }}
                className={`w-full text-left p-6 transition-all relative group border-b border-[#1E293B]/50 ${activeChannel?.id === channel.id ? 'bg-indigo-600/10' : 'hover:bg-[#1E293B]/20'}`}
              >
                <div className="flex items-center gap-3">
                  <Hash className={`w-4 h-4 ${activeChannel?.id === channel.id ? 'text-indigo-400' : 'text-slate-600'}`} />
                  <span className={`font-bold text-sm truncate ${activeChannel?.id === channel.id ? 'text-indigo-400' : 'text-slate-200'}`}>{channel.name}</span>
                </div>
              </button>
            ))
          )}
        </div>
      </div>

      <div className="flex-1 flex flex-col bg-[#0b1221] relative">
        {(activeTicket || activeChannel) ? (
          <>
            <div className="h-16 border-b border-[#1E293B] flex items-center justify-between px-8 bg-[#0F172A]/80 backdrop-blur-md z-10">
              <div className="flex items-center gap-4">
                <div className="w-10 h-10 bg-indigo-600/10 border border-indigo-500/20 rounded-2xl flex items-center justify-center font-black text-indigo-400">
                  {activeTicket ? activeTicket.userName.charAt(0) : '#'}
                </div>
                <div className="space-y-0.5">
                  <h3 className="font-bold text-sm text-white tracking-tight">
                    {activeTicket ? activeTicket.userName : `#${activeChannel?.name}`}
                  </h3>
                  <div className="flex items-center gap-2">
                     <div className="w-1 h-1 rounded-full bg-emerald-500" />
                     <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest leading-none">
                       {activeTicket ? 'Active Ticket' : 'Live Channel Monitor'}
                     </p>
                  </div>
                </div>
              </div>
              <div className="flex gap-2">
                {activeTicket && (
                  <button 
                    onClick={closeTicket}
                    className="px-4 py-2 bg-rose-500/10 hover:bg-rose-500/20 text-rose-500 text-[10px] font-bold uppercase tracking-widest rounded-xl transition-all border border-rose-500/20"
                  >
                    Terminate
                  </button>
                )}
                <div className="w-px h-6 bg-slate-800 my-auto mx-1" />
                <button className="p-2 text-slate-500 hover:text-white transition-colors">
                   <Settings className="w-4 h-4" />
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-auto p-10 space-y-8 bg-[#020617]/10 custom-scrollbar pb-32">
              {messages.map((msg, i) => {
                const isMe = msg.source === 'web';
                return (
                  <div key={msg.id || i} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                    <div className="max-w-[75%]">
                      <div className={`px-5 py-3.5 rounded-[1.25rem] text-sm leading-relaxed shadow-lg ${isMe ? 'bg-indigo-600 text-white' : 'bg-[#1E293B] text-slate-200 shadow-black/20 border border-[#1E293B]/50'}`}>
                        {msg.content}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="absolute inset-x-0 bottom-0 p-8 bg-gradient-to-t from-[#0b1221] via-[#0b1221] to-transparent">
               <form onSubmit={sendMessage} className="bg-[#020617] border border-[#1E293B] rounded-3xl p-3 flex items-center gap-3 shadow-2xl relative group">
                  <input 
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    placeholder={activeTicket ? "Response..." : "Broadcast to channel..."}
                    className="flex-1 bg-transparent border-none px-5 py-3 text-sm focus:outline-none text-white placeholder:text-slate-700"
                  />
                  <button type="submit" disabled={!newMessage.trim() || sending} className="w-12 h-12 bg-indigo-600 hover:bg-indigo-500 text-white rounded-2xl flex items-center justify-center transition-all shadow-xl active:scale-95 disabled:opacity-50"><Send className="w-5 h-5" /></button>
               </form>
            </div>
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-500 p-8 text-center space-y-8 relative overflow-hidden">
             <div className="bg-[#1E293B]/20 border border-[#1E293B] w-32 h-32 rounded-[3.5rem] flex items-center justify-center">
                <TicketIcon className="w-16 h-16 text-slate-800" />
             </div>
             <div className="space-y-3">
                <h3 className="text-3xl font-black text-white/50 tracking-tight uppercase">Null Signal</h3>
                <p className="text-xs font-bold text-slate-600 max-w-[280px] mx-auto uppercase tracking-[0.2em]">Select a transmission node to begin protocol</p>
             </div>
          </div>
        )}
      </div>
    </div>
  );
}
